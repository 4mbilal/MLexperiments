clear all
close all
clc

% net = resnet50;

% net = squeezenet;
% analyzeNetwork(net)
% return

load("ksa_landmarks_resnet18.mat");

I = imread("blue.jpg");

inputSize = net.Layers(1).InputSize;
I = imresize(I,inputSize(1:2));

% label = classify(net,I);
label = predict(net,dlarray(single(I)))
figure
imshow(I)
title(string(label))
% scoreMap = gradCAM(net,I,label);
% figure
% imshow(I)
% hold on
% imagesc(scoreMap,'AlphaData',0.5)
% colormap jet
% pause
% figure
% cam = webcam;
% while(1)
%     img = snapshot(cam);
%     I = imresize(img,inputSize(1:2));
%     tic
%     label = classify(net,I);
%     toc
%     imshow(I)
%     title(string(label))
%     drawnow
% end